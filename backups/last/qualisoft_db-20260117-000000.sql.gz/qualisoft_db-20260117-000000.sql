--
-- PostgreSQL database dump
--

\restrict TlTdCGasVZdB1FggkE9yGXWKvkAwyk1wenALcNbaIeSr7GvVnlDrByETrHTv7NC

-- Dumped from database version 16.11
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActionOrigin; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActionOrigin" AS ENUM (
    'AUDIT',
    'NON_CONFORMITE',
    'RECLAMATION',
    'REVUE_DIRECTION',
    'COPIL',
    'RISQUE',
    'SSE',
    'AUTRE'
);


ALTER TYPE public."ActionOrigin" OWNER TO postgres;

--
-- Name: ActionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActionStatus" AS ENUM (
    'A_FAIRE',
    'EN_COURS',
    'A_VALIDER',
    'TERMINEE',
    'NON_EFFICACE',
    'ANNULEE',
    'EN_RETARD'
);


ALTER TYPE public."ActionStatus" OWNER TO postgres;

--
-- Name: ActionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActionType" AS ENUM (
    'CORRECTIVE',
    'PREVENTIVE',
    'AMELIORATION'
);


ALTER TYPE public."ActionType" OWNER TO postgres;

--
-- Name: ActivityStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActivityStatus" AS ENUM (
    'PLANNED',
    'IN_PROGRESS',
    'DONE',
    'POSTPONED',
    'CANCELLED'
);


ALTER TYPE public."ActivityStatus" OWNER TO postgres;

--
-- Name: AuditStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AuditStatus" AS ENUM (
    'PLANIFIE',
    'EN_COURS',
    'TERMINE',
    'ANNULE'
);


ALTER TYPE public."AuditStatus" OWNER TO postgres;

--
-- Name: DocCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DocCategory" AS ENUM (
    'PROCEDURE',
    'MANUEL',
    'ENREGISTREMENT',
    'CONSIGNE',
    'RAPPORT',
    'AUTRE'
);


ALTER TYPE public."DocCategory" OWNER TO postgres;

--
-- Name: DocStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DocStatus" AS ENUM (
    'BROUILLON',
    'EN_REVUE',
    'APPROUVE',
    'REJETE',
    'ARCHIVE',
    'OBSOLETE'
);


ALTER TYPE public."DocStatus" OWNER TO postgres;

--
-- Name: FindingType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."FindingType" AS ENUM (
    'POINT_FORT',
    'CONFORMITE',
    'OBSERVATION',
    'NC_MINEURE',
    'NC_MAJEURE'
);


ALTER TYPE public."FindingType" OWNER TO postgres;

--
-- Name: GovernanceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GovernanceType" AS ENUM (
    'COPIL',
    'REVUE_DIRECTION',
    'REVUE_PROCESSUS',
    'AUDIT_INTERNE',
    'AUDIT_EXTERNE',
    'VEILLE_REGLEMENTAIRE',
    'SEANCE_PROCESSUS'
);


ALTER TYPE public."GovernanceType" OWNER TO postgres;

--
-- Name: IVStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."IVStatus" AS ENUM (
    'BROUILLON',
    'SOUMIS',
    'VALIDE',
    'RENVOYE'
);


ALTER TYPE public."IVStatus" OWNER TO postgres;

--
-- Name: MeetingStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MeetingStatus" AS ENUM (
    'PLANIFIE',
    'EN_COURS',
    'TERMINE',
    'ANNULE'
);


ALTER TYPE public."MeetingStatus" OWNER TO postgres;

--
-- Name: NCSource; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NCSource" AS ENUM (
    'INTERNAL_AUDIT',
    'EXTERNAL_AUDIT',
    'CLIENT_COMPLAINT',
    'SUPPLIER',
    'INCIDENT_SAFETY'
);


ALTER TYPE public."NCSource" OWNER TO postgres;

--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'WAVE',
    'ORANGE_MONEY',
    'CREDIT_CARD',
    'BANK_TRANSFER',
    'ESSAI'
);


ALTER TYPE public."PaymentMethod" OWNER TO postgres;

--
-- Name: Plan; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Plan" AS ENUM (
    'ESSAI',
    'FREE',
    'BASIC',
    'PRO',
    'EMERGENCE',
    'CROISSANCE',
    'ENTREPRISE',
    'GROUPE'
);


ALTER TYPE public."Plan" OWNER TO postgres;

--
-- Name: Priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Priority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT',
    'CRITICAL'
);


ALTER TYPE public."Priority" OWNER TO postgres;

--
-- Name: ReclamationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReclamationStatus" AS ENUM (
    'NOUVELLE',
    'EN_ANALYSE',
    'ACTION_EN_COURS',
    'TRAITEE',
    'REJETEE'
);


ALTER TYPE public."ReclamationStatus" OWNER TO postgres;

--
-- Name: ReviewStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReviewStatus" AS ENUM (
    'BROUILLON',
    'EN_COURS',
    'VALIDEE',
    'CLOTUREE'
);


ALTER TYPE public."ReviewStatus" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'USER',
    'PILOTE',
    'COPILOTE',
    'AUDITEUR',
    'HSE',
    'SAFETY_OFFICER'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: SSEType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SSEType" AS ENUM (
    'ACCIDENT_TRAVAIL',
    'ACCIDENT_TRAVAIL_TRAJET',
    'DOMMAGE_MATERIEL',
    'PRESQU_ACCIDENT',
    'SITUATION_DANGEREUSE',
    'MALADIE_PRO'
);


ALTER TYPE public."SSEType" OWNER TO postgres;

--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'TRIAL',
    'ACTIVE',
    'SUSPENDED',
    'EXPIRED',
    'PENDING'
);


ALTER TYPE public."SubscriptionStatus" OWNER TO postgres;

--
-- Name: TicketStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TicketStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'RESOLVED',
    'CLOSED',
    'ARCHIVED'
);


ALTER TYPE public."TicketStatus" OWNER TO postgres;

--
-- Name: TierType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TierType" AS ENUM (
    'CLIENT',
    'FOURNISSEUR',
    'PARTENAIRE',
    'ETAT'
);


ALTER TYPE public."TierType" OWNER TO postgres;

--
-- Name: TransactionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TransactionStatus" AS ENUM (
    'EN_COURS',
    'COMPLETE',
    'ECHOUEE',
    'A_REFAIRE'
);


ALTER TYPE public."TransactionStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Action" (
    "ACT_Id" text NOT NULL,
    "ACT_Title" text NOT NULL,
    "ACT_Description" text,
    "ACT_Origin" public."ActionOrigin" DEFAULT 'AUTRE'::public."ActionOrigin" NOT NULL,
    "ACT_Type" public."ActionType" DEFAULT 'CORRECTIVE'::public."ActionType" NOT NULL,
    "ACT_Status" public."ActionStatus" DEFAULT 'A_FAIRE'::public."ActionStatus" NOT NULL,
    "ACT_Priority" public."Priority" DEFAULT 'MEDIUM'::public."Priority" NOT NULL,
    "ACT_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ACT_Deadline" timestamp(3) without time zone,
    "ACT_CompletedAt" timestamp(3) without time zone,
    "ACT_ResponsableId" text NOT NULL,
    "ACT_CreatorId" text NOT NULL,
    "ACT_PAQId" text NOT NULL,
    "ACT_NCId" text,
    "ACT_ReclamationId" text,
    "ACT_AuditId" text,
    "ACT_MeetingId" text,
    "ACT_SSEEventId" text,
    "tenantId" text NOT NULL,
    "ACT_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Action" OWNER TO postgres;

--
-- Name: Audit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Audit" (
    "AU_Id" text NOT NULL,
    "AU_Reference" text NOT NULL,
    "AU_Title" text NOT NULL,
    "AU_Scope" text NOT NULL,
    "AU_DateAudit" timestamp(3) without time zone NOT NULL,
    "AU_Status" public."AuditStatus" DEFAULT 'PLANIFIE'::public."AuditStatus" NOT NULL,
    "AU_LeadId" text,
    "AU_SiteId" text NOT NULL,
    "AU_ProcessusId" text,
    "tenantId" text NOT NULL,
    "AU_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "AU_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Audit" OWNER TO postgres;

--
-- Name: Causerie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Causerie" (
    "CS_Id" text NOT NULL,
    "CS_Theme" text NOT NULL,
    "CS_Date" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "CS_CompteRendu" text,
    "CS_AnimateurId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Causerie" OWNER TO postgres;

--
-- Name: Competence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Competence" (
    "CP_Id" text NOT NULL,
    "CP_Name" text NOT NULL,
    "CP_NiveauRequis" integer NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Competence" OWNER TO postgres;

--
-- Name: Document; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Document" (
    "DOC_Id" text NOT NULL,
    "DOC_Title" text NOT NULL,
    "DOC_Description" text,
    "DOC_Category" public."DocCategory" DEFAULT 'AUTRE'::public."DocCategory" NOT NULL,
    "DOC_Status" public."DocStatus" DEFAULT 'BROUILLON'::public."DocStatus" NOT NULL,
    "DOC_CurrentVersion" integer DEFAULT 1 NOT NULL,
    "DOC_IsArchived" boolean DEFAULT false NOT NULL,
    "tenantId" text NOT NULL,
    "DOC_SiteId" text,
    "DOC_ProcessusId" text,
    "DOC_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "DOC_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Document" OWNER TO postgres;

--
-- Name: DocumentVersion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DocumentVersion" (
    "DV_Id" text NOT NULL,
    "DV_VersionNumber" integer NOT NULL,
    "DV_FileUrl" text NOT NULL,
    "DV_FileName" text NOT NULL,
    "DV_FileSize" integer DEFAULT 0 NOT NULL,
    "DV_Status" public."DocStatus" DEFAULT 'BROUILLON'::public."DocStatus" NOT NULL,
    "DV_DocumentId" text NOT NULL,
    "DV_CreatedById" text NOT NULL,
    "DV_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DocumentVersion" OWNER TO postgres;

--
-- Name: Equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Equipment" (
    "EQ_Id" text NOT NULL,
    "EQ_Reference" text NOT NULL,
    "EQ_Name" text NOT NULL,
    "EQ_DateService" timestamp(3) without time zone NOT NULL,
    "EQ_ProchaineVGP" timestamp(3) without time zone NOT NULL,
    "EQ_Status" text DEFAULT 'OPERATIONNEL'::text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Equipment" OWNER TO postgres;

--
-- Name: Finding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Finding" (
    "FI_Id" text NOT NULL,
    "FI_Description" text NOT NULL,
    "FI_Type" public."FindingType" NOT NULL,
    "FI_AuditId" text NOT NULL
);


ALTER TABLE public."Finding" OWNER TO postgres;

--
-- Name: Formation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Formation" (
    "FOR_Id" text NOT NULL,
    "FOR_Title" text NOT NULL,
    "FOR_Date" timestamp(3) without time zone NOT NULL,
    "FOR_Expiry" timestamp(3) without time zone,
    "FOR_Status" text NOT NULL,
    "FOR_UserId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Formation" OWNER TO postgres;

--
-- Name: GovernanceActivity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GovernanceActivity" (
    "GA_Id" text NOT NULL,
    "GA_Num" text,
    "GA_Title" text NOT NULL,
    "GA_Type" public."GovernanceType" NOT NULL,
    "GA_Theme" text,
    "GA_DatePlanned" timestamp(3) without time zone NOT NULL,
    "GA_Deadline" timestamp(3) without time zone,
    "GA_AnalysisPeriod" text,
    "GA_IpDate" timestamp(3) without time zone,
    "GA_EffectiveDate" timestamp(3) without time zone,
    "GA_Location" text DEFAULT 'Teams'::text,
    "GA_Status" public."ActivityStatus" DEFAULT 'PLANNED'::public."ActivityStatus" NOT NULL,
    "GA_Comments" text,
    "GA_Observations" text,
    "tenantId" text NOT NULL,
    "GA_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "GA_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."GovernanceActivity" OWNER TO postgres;

--
-- Name: Indicator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Indicator" (
    "IND_Id" text NOT NULL,
    "IND_Code" text NOT NULL,
    "IND_Libelle" text NOT NULL,
    "IND_Unite" text NOT NULL,
    "IND_Cible" double precision NOT NULL,
    "IND_Frequence" text DEFAULT 'MENSUEL'::text NOT NULL,
    "IND_ProcessusId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Indicator" OWNER TO postgres;

--
-- Name: IndicatorValue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."IndicatorValue" (
    "IV_Id" text NOT NULL,
    "IV_Month" integer NOT NULL,
    "IV_Year" integer NOT NULL,
    "IV_Actual" double precision NOT NULL,
    "IV_Status" public."IVStatus" DEFAULT 'BROUILLON'::public."IVStatus" NOT NULL,
    "IV_IndicatorId" text NOT NULL,
    "IV_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "IV_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."IndicatorValue" OWNER TO postgres;

--
-- Name: Meeting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Meeting" (
    "MG_Id" text NOT NULL,
    "MG_Title" text NOT NULL,
    "MG_Date" timestamp(3) without time zone NOT NULL,
    "MG_Status" public."MeetingStatus" DEFAULT 'PLANIFIE'::public."MeetingStatus" NOT NULL,
    "MG_Report" text,
    "MG_ProcessId" text,
    "tenantId" text NOT NULL,
    "MG_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "MG_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Meeting" OWNER TO postgres;

--
-- Name: MeetingAttendee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MeetingAttendee" (
    "MA_Id" text NOT NULL,
    "MA_MeetingId" text NOT NULL,
    "MA_UserId" text NOT NULL,
    "MA_Present" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."MeetingAttendee" OWNER TO postgres;

--
-- Name: NonConformite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NonConformite" (
    "NC_Id" text NOT NULL,
    "NC_Libelle" text NOT NULL,
    "NC_Description" text NOT NULL,
    "NC_Diagnostic" text,
    "NC_Gravite" text DEFAULT 'MINEURE'::text NOT NULL,
    "NC_Statut" text DEFAULT 'DETECTION'::text NOT NULL,
    "NC_Source" public."NCSource" DEFAULT 'INTERNAL_AUDIT'::public."NCSource" NOT NULL,
    "NC_ProcessusId" text,
    "NC_ReclamationId" text,
    "NC_AuditId" text,
    "NC_DetectorId" text,
    "tenantId" text NOT NULL,
    "NC_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."NonConformite" OWNER TO postgres;

--
-- Name: OrgUnit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrgUnit" (
    "OU_Id" text NOT NULL,
    "OU_Name" text NOT NULL,
    "OU_TypeId" text NOT NULL,
    "OU_ParentId" text,
    "OU_SiteId" text NOT NULL,
    "tenantId" text NOT NULL,
    "OU_IsActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."OrgUnit" OWNER TO postgres;

--
-- Name: OrgUnitType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrgUnitType" (
    "OUT_Id" text NOT NULL,
    "OUT_Label" text NOT NULL,
    "OUT_Description" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."OrgUnitType" OWNER TO postgres;

--
-- Name: PAQ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PAQ" (
    "PAQ_Id" text NOT NULL,
    "PAQ_Title" text NOT NULL,
    "PAQ_Description" text,
    "PAQ_Year" integer NOT NULL,
    "PAQ_ProcessusId" text NOT NULL,
    "PAQ_QualityManagerId" text NOT NULL,
    "tenantId" text NOT NULL,
    "PAQ_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "PAQ_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PAQ" OWNER TO postgres;

--
-- Name: Preuve; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Preuve" (
    "PV_Id" text NOT NULL,
    "PV_Commentaire" text,
    "PV_FileUrl" text NOT NULL,
    "PV_FileName" text NOT NULL,
    "PV_AuditId" text,
    "PV_NCId" text,
    "PV_ActionId" text,
    "PV_DocumentId" text,
    "tenantId" text NOT NULL,
    "PV_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Preuve" OWNER TO postgres;

--
-- Name: ProcessReview; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProcessReview" (
    "PRV_Id" text NOT NULL,
    "PRV_Month" integer NOT NULL,
    "PRV_Year" integer NOT NULL,
    "PRV_Status" public."ReviewStatus" DEFAULT 'BROUILLON'::public."ReviewStatus" NOT NULL,
    "PRV_AuditAnalysis" text,
    "PRV_PerformanceAnalysis" text,
    "PRV_ResourcesAnalysis" text,
    "PRV_Decisions" text,
    "PRV_RiskAnalysis" text,
    "PRV_DocRef" text DEFAULT 'F-QLT-011'::text,
    "PRV_PiloteSigned" boolean DEFAULT false NOT NULL,
    "PRV_RQSigned" boolean DEFAULT false NOT NULL,
    "PRV_ProcessusId" text NOT NULL,
    "tenantId" text NOT NULL,
    "PRV_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "PRV_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProcessReview" OWNER TO postgres;

--
-- Name: ProcessType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProcessType" (
    "PT_Id" text NOT NULL,
    "PT_Label" text NOT NULL,
    "PT_Description" text,
    "PT_Color" text DEFAULT '#3b82f6'::text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ProcessType" OWNER TO postgres;

--
-- Name: Processus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Processus" (
    "PR_Id" text NOT NULL,
    "PR_Code" text NOT NULL,
    "PR_Libelle" text NOT NULL,
    "PR_Description" text,
    "PR_TypeId" text NOT NULL,
    "PR_PiloteId" text NOT NULL,
    "PR_CoPiloteId" text,
    "tenantId" text NOT NULL,
    "PR_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "PR_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Processus" OWNER TO postgres;

--
-- Name: Reclamation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Reclamation" (
    "REC_Id" text NOT NULL,
    "REC_Reference" text NOT NULL,
    "REC_Object" text NOT NULL,
    "REC_Description" text NOT NULL,
    "REC_Status" public."ReclamationStatus" DEFAULT 'NOUVELLE'::public."ReclamationStatus" NOT NULL,
    "REC_Source" text,
    "REC_DateReceipt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "REC_DateTransmitted" timestamp(3) without time zone,
    "REC_Deadline" timestamp(3) without time zone,
    "REC_Gravity" public."Priority" DEFAULT 'MEDIUM'::public."Priority" NOT NULL,
    "REC_TierId" text NOT NULL,
    "REC_ProcessusId" text,
    "REC_OwnerId" text NOT NULL,
    "tenantId" text NOT NULL,
    "REC_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "REC_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Reclamation" OWNER TO postgres;

--
-- Name: RevueDirection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RevueDirection" (
    "RD_Id" text NOT NULL,
    "RD_Periode" text NOT NULL,
    "RD_Date" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    "RD_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RevueDirection" OWNER TO postgres;

--
-- Name: Risk; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Risk" (
    "RS_Id" text NOT NULL,
    "RS_Libelle" text NOT NULL,
    "RS_Activite" text,
    "RS_Tache" text,
    "RS_Causes" text,
    "RS_Description" text,
    "RS_Probabilite" integer DEFAULT 1 NOT NULL,
    "RS_Gravite" integer DEFAULT 1 NOT NULL,
    "RS_Maitrise" integer DEFAULT 1 NOT NULL,
    "RS_Score" integer DEFAULT 1 NOT NULL,
    "RS_Status" text DEFAULT 'IDENTIFIE'::text,
    "RS_Mesures" text,
    "RS_Acteurs" text,
    "RS_NextReview" timestamp(3) without time zone,
    "RS_TypeId" text NOT NULL,
    "RS_ProcessusId" text NOT NULL,
    "tenantId" text NOT NULL,
    "RS_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "RS_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Risk" OWNER TO postgres;

--
-- Name: RiskType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RiskType" (
    "RT_Id" text NOT NULL,
    "RT_Label" text NOT NULL,
    "RT_Description" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."RiskType" OWNER TO postgres;

--
-- Name: SSEEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SSEEvent" (
    "SSE_Id" text NOT NULL,
    "SSE_Type" public."SSEType" NOT NULL,
    "SSE_DateEvent" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "SSE_Lieu" text NOT NULL,
    "SSE_Description" text NOT NULL,
    "SSE_AvecArret" boolean DEFAULT false NOT NULL,
    "SSE_NbJoursArret" integer DEFAULT 0 NOT NULL,
    "SSE_ReporterId" text,
    "SSE_VictimId" text,
    "SSE_SiteId" text NOT NULL,
    "SSE_ProcessusId" text,
    "tenantId" text NOT NULL,
    "SSE_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SSEEvent" OWNER TO postgres;

--
-- Name: SSEStats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SSEStats" (
    "ST_Id" text NOT NULL,
    "ST_Mois" integer NOT NULL,
    "ST_Annee" integer NOT NULL,
    "ST_NbAccidents" integer NOT NULL,
    "ST_TauxFrequence" double precision DEFAULT 0 NOT NULL,
    "ST_TauxGravite" double precision DEFAULT 0 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."SSEStats" OWNER TO postgres;

--
-- Name: SecurityAuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SecurityAuditLog" (
    "SAL_Id" text NOT NULL,
    "SAL_Action" text NOT NULL,
    "SAL_Timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "SAL_UserId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."SecurityAuditLog" OWNER TO postgres;

--
-- Name: Signature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Signature" (
    "SIG_Id" text NOT NULL,
    "SIG_EntityType" text NOT NULL,
    "SIG_EntityId" text NOT NULL,
    "SIG_Hash" text NOT NULL,
    "SIG_Metadata" jsonb,
    "SIG_UserId" text NOT NULL,
    "tenantId" text NOT NULL,
    "SIG_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Signature" OWNER TO postgres;

--
-- Name: Site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Site" (
    "S_Id" text NOT NULL,
    "S_Name" text NOT NULL,
    "S_Address" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Site" OWNER TO postgres;

--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tenant" (
    "T_Id" text NOT NULL,
    "T_Name" text NOT NULL,
    "T_Email" text NOT NULL,
    "T_Domain" text NOT NULL,
    "T_Plan" public."Plan" DEFAULT 'ESSAI'::public."Plan" NOT NULL,
    "T_SubscriptionStatus" public."SubscriptionStatus" DEFAULT 'TRIAL'::public."SubscriptionStatus" NOT NULL,
    "T_SubscriptionEndDate" timestamp(3) without time zone,
    "T_IsActive" boolean DEFAULT true NOT NULL,
    "T_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "T_UpdatedAt" timestamp(3) without time zone NOT NULL,
    "T_Address" text,
    "T_Phone" text,
    "T_CeoName" text,
    "T_ContractDuration" integer DEFAULT 24 NOT NULL,
    "T_TacitRenewal" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Tenant" OWNER TO postgres;

--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ticket" (
    "TK_Id" text NOT NULL,
    "TK_Subject" text NOT NULL,
    "TK_Description" text NOT NULL,
    "TK_Status" public."TicketStatus" DEFAULT 'OPEN'::public."TicketStatus" NOT NULL,
    "TK_Priority" public."Priority" DEFAULT 'MEDIUM'::public."Priority" NOT NULL,
    "TK_Response" text,
    "TK_ResponseAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "TK_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "TK_UpdatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Ticket" OWNER TO postgres;

--
-- Name: Tier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tier" (
    "TR_Id" text NOT NULL,
    "TR_Name" text NOT NULL,
    "TR_Email" text,
    "TR_Type" public."TierType" DEFAULT 'CLIENT'::public."TierType" NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Tier" OWNER TO postgres;

--
-- Name: Transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Transaction" (
    "TX_Id" text NOT NULL,
    "TX_Amount" double precision NOT NULL,
    "TX_Currency" text DEFAULT 'XOF'::text NOT NULL,
    "TX_Reference" text NOT NULL,
    "TX_Status" public."TransactionStatus" DEFAULT 'EN_COURS'::public."TransactionStatus" NOT NULL,
    "TX_PaymentMethod" public."PaymentMethod" NOT NULL,
    "TX_ProofUrl" text,
    "TX_AdminComment" text,
    "tenantId" text NOT NULL,
    "TX_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Transaction" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    "U_Id" text NOT NULL,
    "U_Email" text NOT NULL,
    "U_PasswordHash" text NOT NULL,
    "U_FirstName" text,
    "U_LastName" text,
    "U_Role" public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    "U_IsActive" boolean DEFAULT true NOT NULL,
    "U_CreatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "U_UpdatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    "U_SiteId" text,
    "U_OrgUnitId" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: UserCompetence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserCompetence" (
    "UC_UserId" text NOT NULL,
    "UC_CompetenceId" text NOT NULL,
    "UC_NiveauActuel" integer NOT NULL
);


ALTER TABLE public."UserCompetence" OWNER TO postgres;

--
-- Name: _ParticipantsCauserie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_ParticipantsCauserie" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_ParticipantsCauserie" OWNER TO postgres;

--
-- Name: _ProcessGovernance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_ProcessGovernance" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_ProcessGovernance" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: Action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Action" ("ACT_Id", "ACT_Title", "ACT_Description", "ACT_Origin", "ACT_Type", "ACT_Status", "ACT_Priority", "ACT_CreatedAt", "ACT_Deadline", "ACT_CompletedAt", "ACT_ResponsableId", "ACT_CreatorId", "ACT_PAQId", "ACT_NCId", "ACT_ReclamationId", "ACT_AuditId", "ACT_MeetingId", "ACT_SSEEventId", "tenantId", "ACT_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Audit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Audit" ("AU_Id", "AU_Reference", "AU_Title", "AU_Scope", "AU_DateAudit", "AU_Status", "AU_LeadId", "AU_SiteId", "AU_ProcessusId", "tenantId", "AU_CreatedAt", "AU_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Causerie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Causerie" ("CS_Id", "CS_Theme", "CS_Date", "CS_CompteRendu", "CS_AnimateurId", "tenantId") FROM stdin;
\.


--
-- Data for Name: Competence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Competence" ("CP_Id", "CP_Name", "CP_NiveauRequis", "tenantId") FROM stdin;
\.


--
-- Data for Name: Document; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Document" ("DOC_Id", "DOC_Title", "DOC_Description", "DOC_Category", "DOC_Status", "DOC_CurrentVersion", "DOC_IsArchived", "tenantId", "DOC_SiteId", "DOC_ProcessusId", "DOC_CreatedAt", "DOC_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: DocumentVersion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DocumentVersion" ("DV_Id", "DV_VersionNumber", "DV_FileUrl", "DV_FileName", "DV_FileSize", "DV_Status", "DV_DocumentId", "DV_CreatedById", "DV_CreatedAt") FROM stdin;
\.


--
-- Data for Name: Equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Equipment" ("EQ_Id", "EQ_Reference", "EQ_Name", "EQ_DateService", "EQ_ProchaineVGP", "EQ_Status", "tenantId") FROM stdin;
\.


--
-- Data for Name: Finding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Finding" ("FI_Id", "FI_Description", "FI_Type", "FI_AuditId") FROM stdin;
\.


--
-- Data for Name: Formation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Formation" ("FOR_Id", "FOR_Title", "FOR_Date", "FOR_Expiry", "FOR_Status", "FOR_UserId", "tenantId") FROM stdin;
\.


--
-- Data for Name: GovernanceActivity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GovernanceActivity" ("GA_Id", "GA_Num", "GA_Title", "GA_Type", "GA_Theme", "GA_DatePlanned", "GA_Deadline", "GA_AnalysisPeriod", "GA_IpDate", "GA_EffectiveDate", "GA_Location", "GA_Status", "GA_Comments", "GA_Observations", "tenantId", "GA_CreatedAt", "GA_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Indicator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Indicator" ("IND_Id", "IND_Code", "IND_Libelle", "IND_Unite", "IND_Cible", "IND_Frequence", "IND_ProcessusId", "tenantId") FROM stdin;
\.


--
-- Data for Name: IndicatorValue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."IndicatorValue" ("IV_Id", "IV_Month", "IV_Year", "IV_Actual", "IV_Status", "IV_IndicatorId", "IV_CreatedAt", "IV_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Meeting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Meeting" ("MG_Id", "MG_Title", "MG_Date", "MG_Status", "MG_Report", "MG_ProcessId", "tenantId", "MG_CreatedAt", "MG_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: MeetingAttendee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MeetingAttendee" ("MA_Id", "MA_MeetingId", "MA_UserId", "MA_Present") FROM stdin;
\.


--
-- Data for Name: NonConformite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NonConformite" ("NC_Id", "NC_Libelle", "NC_Description", "NC_Diagnostic", "NC_Gravite", "NC_Statut", "NC_Source", "NC_ProcessusId", "NC_ReclamationId", "NC_AuditId", "NC_DetectorId", "tenantId", "NC_CreatedAt") FROM stdin;
\.


--
-- Data for Name: OrgUnit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrgUnit" ("OU_Id", "OU_Name", "OU_TypeId", "OU_ParentId", "OU_SiteId", "tenantId", "OU_IsActive") FROM stdin;
\.


--
-- Data for Name: OrgUnitType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrgUnitType" ("OUT_Id", "OUT_Label", "OUT_Description", "tenantId") FROM stdin;
\.


--
-- Data for Name: PAQ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PAQ" ("PAQ_Id", "PAQ_Title", "PAQ_Description", "PAQ_Year", "PAQ_ProcessusId", "PAQ_QualityManagerId", "tenantId", "PAQ_CreatedAt", "PAQ_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Preuve; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Preuve" ("PV_Id", "PV_Commentaire", "PV_FileUrl", "PV_FileName", "PV_AuditId", "PV_NCId", "PV_ActionId", "PV_DocumentId", "tenantId", "PV_CreatedAt") FROM stdin;
\.


--
-- Data for Name: ProcessReview; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProcessReview" ("PRV_Id", "PRV_Month", "PRV_Year", "PRV_Status", "PRV_AuditAnalysis", "PRV_PerformanceAnalysis", "PRV_ResourcesAnalysis", "PRV_Decisions", "PRV_RiskAnalysis", "PRV_DocRef", "PRV_PiloteSigned", "PRV_RQSigned", "PRV_ProcessusId", "tenantId", "PRV_CreatedAt", "PRV_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: ProcessType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProcessType" ("PT_Id", "PT_Label", "PT_Description", "PT_Color", "tenantId") FROM stdin;
\.


--
-- Data for Name: Processus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Processus" ("PR_Id", "PR_Code", "PR_Libelle", "PR_Description", "PR_TypeId", "PR_PiloteId", "PR_CoPiloteId", "tenantId", "PR_CreatedAt", "PR_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Reclamation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Reclamation" ("REC_Id", "REC_Reference", "REC_Object", "REC_Description", "REC_Status", "REC_Source", "REC_DateReceipt", "REC_DateTransmitted", "REC_Deadline", "REC_Gravity", "REC_TierId", "REC_ProcessusId", "REC_OwnerId", "tenantId", "REC_CreatedAt", "REC_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: RevueDirection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RevueDirection" ("RD_Id", "RD_Periode", "RD_Date", "tenantId", "RD_CreatedAt") FROM stdin;
\.


--
-- Data for Name: Risk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Risk" ("RS_Id", "RS_Libelle", "RS_Activite", "RS_Tache", "RS_Causes", "RS_Description", "RS_Probabilite", "RS_Gravite", "RS_Maitrise", "RS_Score", "RS_Status", "RS_Mesures", "RS_Acteurs", "RS_NextReview", "RS_TypeId", "RS_ProcessusId", "tenantId", "RS_CreatedAt", "RS_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: RiskType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RiskType" ("RT_Id", "RT_Label", "RT_Description", "tenantId") FROM stdin;
\.


--
-- Data for Name: SSEEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SSEEvent" ("SSE_Id", "SSE_Type", "SSE_DateEvent", "SSE_Lieu", "SSE_Description", "SSE_AvecArret", "SSE_NbJoursArret", "SSE_ReporterId", "SSE_VictimId", "SSE_SiteId", "SSE_ProcessusId", "tenantId", "SSE_CreatedAt") FROM stdin;
\.


--
-- Data for Name: SSEStats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SSEStats" ("ST_Id", "ST_Mois", "ST_Annee", "ST_NbAccidents", "ST_TauxFrequence", "ST_TauxGravite", "tenantId") FROM stdin;
\.


--
-- Data for Name: SecurityAuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SecurityAuditLog" ("SAL_Id", "SAL_Action", "SAL_Timestamp", "SAL_UserId", "tenantId") FROM stdin;
\.


--
-- Data for Name: Signature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Signature" ("SIG_Id", "SIG_EntityType", "SIG_EntityId", "SIG_Hash", "SIG_Metadata", "SIG_UserId", "tenantId", "SIG_CreatedAt") FROM stdin;
\.


--
-- Data for Name: Site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Site" ("S_Id", "S_Name", "S_Address", "tenantId") FROM stdin;
cd4e68bc-ea38-473d-bfa7-3fe98b4be32f	Siège Social	Campus UCAD	384716d8-784c-4503-a695-9e0dea35356e
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tenant" ("T_Id", "T_Name", "T_Email", "T_Domain", "T_Plan", "T_SubscriptionStatus", "T_SubscriptionEndDate", "T_IsActive", "T_CreatedAt", "T_UpdatedAt", "T_Address", "T_Phone", "T_CeoName", "T_ContractDuration", "T_TacitRenewal") FROM stdin;
384716d8-784c-4503-a695-9e0dea35356e	Sagam	pierre.ndiaye@sagam.sn	sagam	ENTREPRISE	TRIAL	2026-01-30 22:34:45.051	t	2026-01-16 22:34:45.055	2026-01-16 22:34:45.055	Campus UCAD	33 865 15 15	Faly SENE	24	t
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ticket" ("TK_Id", "TK_Subject", "TK_Description", "TK_Status", "TK_Priority", "TK_Response", "TK_ResponseAt", "tenantId", "TK_CreatedAt", "TK_UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Tier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tier" ("TR_Id", "TR_Name", "TR_Email", "TR_Type", "tenantId") FROM stdin;
\.


--
-- Data for Name: Transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Transaction" ("TX_Id", "TX_Amount", "TX_Currency", "TX_Reference", "TX_Status", "TX_PaymentMethod", "TX_ProofUrl", "TX_AdminComment", "tenantId", "TX_CreatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" ("U_Id", "U_Email", "U_PasswordHash", "U_FirstName", "U_LastName", "U_Role", "U_IsActive", "U_CreatedAt", "U_UpdatedAt", "tenantId", "U_SiteId", "U_OrgUnitId") FROM stdin;
57cd57eb-c3d5-4c25-8fa1-7ce31609d85e	pierre.ndiaye@sagam.sn	$2b$10$kQZyM586QMcmwGEN.I0Pje/rTVpUIYpomgmHYBbk89dCVlux5MoRi	Pierre 	Ndiaye	ADMIN	t	2026-01-16 22:34:45.177	2026-01-16 22:34:45.177	384716d8-784c-4503-a695-9e0dea35356e	cd4e68bc-ea38-473d-bfa7-3fe98b4be32f	\N
\.


--
-- Data for Name: UserCompetence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserCompetence" ("UC_UserId", "UC_CompetenceId", "UC_NiveauActuel") FROM stdin;
\.


--
-- Data for Name: _ParticipantsCauserie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_ParticipantsCauserie" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _ProcessGovernance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_ProcessGovernance" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
235afe0a-00cc-4d3c-8992-725d62003b3b	68c1812514a30a5e0adcb06ed0d2fd0e195495654f56385e51a6ed19279d19c0	2026-01-16 18:25:12.191484+00	20260105083956_structural_normalization_v2	\N	\N	2026-01-16 18:25:11.875597+00	1
\.


--
-- Name: Action Action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_pkey" PRIMARY KEY ("ACT_Id");


--
-- Name: Audit Audit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Audit"
    ADD CONSTRAINT "Audit_pkey" PRIMARY KEY ("AU_Id");


--
-- Name: Causerie Causerie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Causerie"
    ADD CONSTRAINT "Causerie_pkey" PRIMARY KEY ("CS_Id");


--
-- Name: Competence Competence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Competence"
    ADD CONSTRAINT "Competence_pkey" PRIMARY KEY ("CP_Id");


--
-- Name: DocumentVersion DocumentVersion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DocumentVersion"
    ADD CONSTRAINT "DocumentVersion_pkey" PRIMARY KEY ("DV_Id");


--
-- Name: Document Document_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "Document_pkey" PRIMARY KEY ("DOC_Id");


--
-- Name: Equipment Equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_pkey" PRIMARY KEY ("EQ_Id");


--
-- Name: Finding Finding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Finding"
    ADD CONSTRAINT "Finding_pkey" PRIMARY KEY ("FI_Id");


--
-- Name: Formation Formation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Formation"
    ADD CONSTRAINT "Formation_pkey" PRIMARY KEY ("FOR_Id");


--
-- Name: GovernanceActivity GovernanceActivity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GovernanceActivity"
    ADD CONSTRAINT "GovernanceActivity_pkey" PRIMARY KEY ("GA_Id");


--
-- Name: IndicatorValue IndicatorValue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IndicatorValue"
    ADD CONSTRAINT "IndicatorValue_pkey" PRIMARY KEY ("IV_Id");


--
-- Name: Indicator Indicator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Indicator"
    ADD CONSTRAINT "Indicator_pkey" PRIMARY KEY ("IND_Id");


--
-- Name: MeetingAttendee MeetingAttendee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MeetingAttendee"
    ADD CONSTRAINT "MeetingAttendee_pkey" PRIMARY KEY ("MA_Id");


--
-- Name: Meeting Meeting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Meeting"
    ADD CONSTRAINT "Meeting_pkey" PRIMARY KEY ("MG_Id");


--
-- Name: NonConformite NonConformite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NonConformite"
    ADD CONSTRAINT "NonConformite_pkey" PRIMARY KEY ("NC_Id");


--
-- Name: OrgUnitType OrgUnitType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrgUnitType"
    ADD CONSTRAINT "OrgUnitType_pkey" PRIMARY KEY ("OUT_Id");


--
-- Name: OrgUnit OrgUnit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrgUnit"
    ADD CONSTRAINT "OrgUnit_pkey" PRIMARY KEY ("OU_Id");


--
-- Name: PAQ PAQ_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PAQ"
    ADD CONSTRAINT "PAQ_pkey" PRIMARY KEY ("PAQ_Id");


--
-- Name: Preuve Preuve_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Preuve"
    ADD CONSTRAINT "Preuve_pkey" PRIMARY KEY ("PV_Id");


--
-- Name: ProcessReview ProcessReview_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProcessReview"
    ADD CONSTRAINT "ProcessReview_pkey" PRIMARY KEY ("PRV_Id");


--
-- Name: ProcessType ProcessType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProcessType"
    ADD CONSTRAINT "ProcessType_pkey" PRIMARY KEY ("PT_Id");


--
-- Name: Processus Processus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Processus"
    ADD CONSTRAINT "Processus_pkey" PRIMARY KEY ("PR_Id");


--
-- Name: Reclamation Reclamation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reclamation"
    ADD CONSTRAINT "Reclamation_pkey" PRIMARY KEY ("REC_Id");


--
-- Name: RevueDirection RevueDirection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RevueDirection"
    ADD CONSTRAINT "RevueDirection_pkey" PRIMARY KEY ("RD_Id");


--
-- Name: RiskType RiskType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskType"
    ADD CONSTRAINT "RiskType_pkey" PRIMARY KEY ("RT_Id");


--
-- Name: Risk Risk_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Risk"
    ADD CONSTRAINT "Risk_pkey" PRIMARY KEY ("RS_Id");


--
-- Name: SSEEvent SSEEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEEvent"
    ADD CONSTRAINT "SSEEvent_pkey" PRIMARY KEY ("SSE_Id");


--
-- Name: SSEStats SSEStats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEStats"
    ADD CONSTRAINT "SSEStats_pkey" PRIMARY KEY ("ST_Id");


--
-- Name: SecurityAuditLog SecurityAuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SecurityAuditLog"
    ADD CONSTRAINT "SecurityAuditLog_pkey" PRIMARY KEY ("SAL_Id");


--
-- Name: Signature Signature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Signature"
    ADD CONSTRAINT "Signature_pkey" PRIMARY KEY ("SIG_Id");


--
-- Name: Site Site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_pkey" PRIMARY KEY ("S_Id");


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY ("T_Id");


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY ("TK_Id");


--
-- Name: Tier Tier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tier"
    ADD CONSTRAINT "Tier_pkey" PRIMARY KEY ("TR_Id");


--
-- Name: Transaction Transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_pkey" PRIMARY KEY ("TX_Id");


--
-- Name: UserCompetence UserCompetence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserCompetence"
    ADD CONSTRAINT "UserCompetence_pkey" PRIMARY KEY ("UC_UserId", "UC_CompetenceId");


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY ("U_Id");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Action_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Action_tenantId_idx" ON public."Action" USING btree ("tenantId");


--
-- Name: Audit_AU_Reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Audit_AU_Reference_key" ON public."Audit" USING btree ("AU_Reference");


--
-- Name: AuditenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditenantId_idx" ON public."Audit" USING btree ("tenantId");


--
-- Name: CauseritenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CauseritenantId_idx" ON public."Causerie" USING btree ("tenantId");


--
-- Name: CompetenctenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CompetenctenantId_idx" ON public."Competence" USING btree ("tenantId");


--
-- Name: DocumentenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DocumentenantId_idx" ON public."Document" USING btree ("tenantId");


--
-- Name: Equipment_EQ_Reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Equipment_EQ_Reference_key" ON public."Equipment" USING btree ("EQ_Reference");


--
-- Name: EquipmentenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "EquipmentenantId_idx" ON public."Equipment" USING btree ("tenantId");


--
-- Name: Formation_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Formation_tenantId_idx" ON public."Formation" USING btree ("tenantId");


--
-- Name: GovernanceActivity_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "GovernanceActivity_tenantId_idx" ON public."GovernanceActivity" USING btree ("tenantId");


--
-- Name: IndicatorValue_IV_IndicatorId_IV_Month_IV_Year_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IndicatorValue_IV_IndicatorId_IV_Month_IV_Year_key" ON public."IndicatorValue" USING btree ("IV_IndicatorId", "IV_Month", "IV_Year");


--
-- Name: IndicattenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IndicattenantId_idx" ON public."Indicator" USING btree ("tenantId");


--
-- Name: Meeting_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Meeting_tenantId_idx" ON public."Meeting" USING btree ("tenantId");


--
-- Name: NonConformitenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NonConformitenantId_idx" ON public."NonConformite" USING btree ("tenantId");


--
-- Name: OrgUnitType_OUT_Label_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "OrgUnitType_OUT_Label_tenantId_key" ON public."OrgUnitType" USING btree ("OUT_Label", "tenantId");


--
-- Name: OrgUnitTytenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrgUnitTytenantId_idx" ON public."OrgUnitType" USING btree ("tenantId");


--
-- Name: OrgUnitenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrgUnitenantId_idx" ON public."OrgUnit" USING btree ("tenantId");


--
-- Name: PAQ_PAQ_ProcessusId_PAQ_YetenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PAQ_PAQ_ProcessusId_PAQ_YetenantId_key" ON public."PAQ" USING btree ("PAQ_ProcessusId", "PAQ_Year", "tenantId");


--
-- Name: PreuvtenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PreuvtenantId_idx" ON public."Preuve" USING btree ("tenantId");


--
-- Name: ProcessReview_PRV_ProcessusId_PRV_Month_PRV_YetenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProcessReview_PRV_ProcessusId_PRV_Month_PRV_YetenantId_key" ON public."ProcessReview" USING btree ("PRV_ProcessusId", "PRV_Month", "PRV_Year", "tenantId");


--
-- Name: ProcessReview_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProcessReview_tenantId_idx" ON public."ProcessReview" USING btree ("tenantId");


--
-- Name: ProcessType_PT_Label_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProcessType_PT_Label_tenantId_key" ON public."ProcessType" USING btree ("PT_Label", "tenantId");


--
-- Name: ProcessTytenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProcessTytenantId_idx" ON public."ProcessType" USING btree ("tenantId");


--
-- Name: Processus_PR_CodtenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Processus_PR_CodtenantId_key" ON public."Processus" USING btree ("PR_Code", "tenantId");


--
-- Name: ProcessutenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProcessutenantId_idx" ON public."Processus" USING btree ("tenantId");


--
-- Name: Reclamation_REC_Reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Reclamation_REC_Reference_key" ON public."Reclamation" USING btree ("REC_Reference");


--
-- Name: Reclamation_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Reclamation_tenantId_idx" ON public."Reclamation" USING btree ("tenantId");


--
-- Name: RevueDirection_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RevueDirection_tenantId_idx" ON public."RevueDirection" USING btree ("tenantId");


--
-- Name: RiskType_RT_Label_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "RiskType_RT_Label_tenantId_key" ON public."RiskType" USING btree ("RT_Label", "tenantId");


--
-- Name: RiskTytenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RiskTytenantId_idx" ON public."RiskType" USING btree ("tenantId");


--
-- Name: Risk_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Risk_tenantId_idx" ON public."Risk" USING btree ("tenantId");


--
-- Name: SSEEventenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SSEEventenantId_idx" ON public."SSEEvent" USING btree ("tenantId");


--
-- Name: SSESttenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SSESttenantId_idx" ON public."SSEStats" USING btree ("tenantId");


--
-- Name: SecurityAuditLog_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SecurityAuditLog_tenantId_idx" ON public."SecurityAuditLog" USING btree ("tenantId");


--
-- Name: SignatutenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SignatutenantId_idx" ON public."Signature" USING btree ("tenantId");


--
-- Name: SitenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SitenantId_idx" ON public."Site" USING btree ("tenantId");


--
-- Name: Tenant_T_Domain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tenant_T_Domain_key" ON public."Tenant" USING btree ("T_Domain");


--
-- Name: Tenant_T_Email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tenant_T_Email_key" ON public."Tenant" USING btree ("T_Email");


--
-- Name: TicketenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TicketenantId_idx" ON public."Ticket" USING btree ("tenantId");


--
-- Name: Tier_TR_ItenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tier_TR_ItenantId_key" ON public."Tier" USING btree ("TR_Id", "tenantId");


--
-- Name: TietenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TietenantId_idx" ON public."Tier" USING btree ("tenantId");


--
-- Name: Transaction_TX_Reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Transaction_TX_Reference_key" ON public."Transaction" USING btree ("TX_Reference");


--
-- Name: Transaction_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Transaction_tenantId_idx" ON public."Transaction" USING btree ("tenantId");


--
-- Name: User_U_Email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_U_Email_key" ON public."User" USING btree ("U_Email");


--
-- Name: UsetenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UsetenantId_idx" ON public."User" USING btree ("tenantId");


--
-- Name: _ParticipantsCauserie_AB_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "_ParticipantsCauserie_AB_unique" ON public."_ParticipantsCauserie" USING btree ("A", "B");


--
-- Name: _ParticipantsCauserie_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_ParticipantsCauserie_B_index" ON public."_ParticipantsCauserie" USING btree ("B");


--
-- Name: _ProcessGovernance_AB_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "_ProcessGovernance_AB_unique" ON public."_ProcessGovernance" USING btree ("A", "B");


--
-- Name: _ProcessGovernance_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_ProcessGovernance_B_index" ON public."_ProcessGovernance" USING btree ("B");


--
-- Name: tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tenantId_idx" ON public."PAQ" USING btree ("tenantId");


--
-- Name: Action Action_ACT_AuditId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_AuditId_fkey" FOREIGN KEY ("ACT_AuditId") REFERENCES public."Audit"("AU_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Action Action_ACT_CreatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_CreatorId_fkey" FOREIGN KEY ("ACT_CreatorId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Action Action_ACT_MeetingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_MeetingId_fkey" FOREIGN KEY ("ACT_MeetingId") REFERENCES public."Meeting"("MG_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Action Action_ACT_NCId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_NCId_fkey" FOREIGN KEY ("ACT_NCId") REFERENCES public."NonConformite"("NC_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Action Action_ACT_PAQId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_PAQId_fkey" FOREIGN KEY ("ACT_PAQId") REFERENCES public."PAQ"("PAQ_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Action Action_ACT_ReclamationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_ReclamationId_fkey" FOREIGN KEY ("ACT_ReclamationId") REFERENCES public."Reclamation"("REC_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Action Action_ACT_ResponsableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_ResponsableId_fkey" FOREIGN KEY ("ACT_ResponsableId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Action Action_ACT_SSEEventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_ACT_SSEEventId_fkey" FOREIGN KEY ("ACT_SSEEventId") REFERENCES public."SSEEvent"("SSE_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Action Action_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Action"
    ADD CONSTRAINT "Action_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Audit Audit_AU_LeadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Audit"
    ADD CONSTRAINT "Audit_AU_LeadId_fkey" FOREIGN KEY ("AU_LeadId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Audit Audit_AU_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Audit"
    ADD CONSTRAINT "Audit_AU_ProcessusId_fkey" FOREIGN KEY ("AU_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Audit Audit_AU_SiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Audit"
    ADD CONSTRAINT "Audit_AU_SiteId_fkey" FOREIGN KEY ("AU_SiteId") REFERENCES public."Site"("S_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Audit AuditenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Audit"
    ADD CONSTRAINT "AuditenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Causerie Causerie_CS_AnimateurId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Causerie"
    ADD CONSTRAINT "Causerie_CS_AnimateurId_fkey" FOREIGN KEY ("CS_AnimateurId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Causerie CauseritenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Causerie"
    ADD CONSTRAINT "CauseritenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Competence CompetenctenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Competence"
    ADD CONSTRAINT "CompetenctenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DocumentVersion DocumentVersion_DV_CreatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DocumentVersion"
    ADD CONSTRAINT "DocumentVersion_DV_CreatedById_fkey" FOREIGN KEY ("DV_CreatedById") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DocumentVersion DocumentVersion_DV_DocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DocumentVersion"
    ADD CONSTRAINT "DocumentVersion_DV_DocumentId_fkey" FOREIGN KEY ("DV_DocumentId") REFERENCES public."Document"("DOC_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Document Document_DOC_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "Document_DOC_ProcessusId_fkey" FOREIGN KEY ("DOC_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Document Document_DOC_SiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "Document_DOC_SiteId_fkey" FOREIGN KEY ("DOC_SiteId") REFERENCES public."Site"("S_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Document DocumentenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "DocumentenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Equipment EquipmentenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "EquipmentenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Finding Finding_FI_AuditId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Finding"
    ADD CONSTRAINT "Finding_FI_AuditId_fkey" FOREIGN KEY ("FI_AuditId") REFERENCES public."Audit"("AU_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Formation Formation_FOR_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Formation"
    ADD CONSTRAINT "Formation_FOR_UserId_fkey" FOREIGN KEY ("FOR_UserId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Formation Formation_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Formation"
    ADD CONSTRAINT "Formation_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GovernanceActivity GovernanceActivity_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GovernanceActivity"
    ADD CONSTRAINT "GovernanceActivity_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: IndicatorValue IndicatorValue_IV_IndicatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IndicatorValue"
    ADD CONSTRAINT "IndicatorValue_IV_IndicatorId_fkey" FOREIGN KEY ("IV_IndicatorId") REFERENCES public."Indicator"("IND_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Indicator Indicator_IND_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Indicator"
    ADD CONSTRAINT "Indicator_IND_ProcessusId_fkey" FOREIGN KEY ("IND_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Indicator IndicattenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Indicator"
    ADD CONSTRAINT "IndicattenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MeetingAttendee MeetingAttendee_MA_MeetingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MeetingAttendee"
    ADD CONSTRAINT "MeetingAttendee_MA_MeetingId_fkey" FOREIGN KEY ("MA_MeetingId") REFERENCES public."Meeting"("MG_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MeetingAttendee MeetingAttendee_MA_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MeetingAttendee"
    ADD CONSTRAINT "MeetingAttendee_MA_UserId_fkey" FOREIGN KEY ("MA_UserId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Meeting Meeting_MG_ProcessId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Meeting"
    ADD CONSTRAINT "Meeting_MG_ProcessId_fkey" FOREIGN KEY ("MG_ProcessId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Meeting Meeting_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Meeting"
    ADD CONSTRAINT "Meeting_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NonConformite NonConformite_NC_AuditId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NonConformite"
    ADD CONSTRAINT "NonConformite_NC_AuditId_fkey" FOREIGN KEY ("NC_AuditId") REFERENCES public."Audit"("AU_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NonConformite NonConformite_NC_DetectorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NonConformite"
    ADD CONSTRAINT "NonConformite_NC_DetectorId_fkey" FOREIGN KEY ("NC_DetectorId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NonConformite NonConformite_NC_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NonConformite"
    ADD CONSTRAINT "NonConformite_NC_ProcessusId_fkey" FOREIGN KEY ("NC_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NonConformite NonConformite_NC_ReclamationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NonConformite"
    ADD CONSTRAINT "NonConformite_NC_ReclamationId_fkey" FOREIGN KEY ("NC_ReclamationId") REFERENCES public."Reclamation"("REC_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NonConformite NonConformitenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NonConformite"
    ADD CONSTRAINT "NonConformitenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrgUnitType OrgUnitTytenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrgUnitType"
    ADD CONSTRAINT "OrgUnitTytenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrgUnit OrgUnit_OU_ParentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrgUnit"
    ADD CONSTRAINT "OrgUnit_OU_ParentId_fkey" FOREIGN KEY ("OU_ParentId") REFERENCES public."OrgUnit"("OU_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrgUnit OrgUnit_OU_SiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrgUnit"
    ADD CONSTRAINT "OrgUnit_OU_SiteId_fkey" FOREIGN KEY ("OU_SiteId") REFERENCES public."Site"("S_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrgUnit OrgUnit_OU_TypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrgUnit"
    ADD CONSTRAINT "OrgUnit_OU_TypeId_fkey" FOREIGN KEY ("OU_TypeId") REFERENCES public."OrgUnitType"("OUT_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrgUnit OrgUnitenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrgUnit"
    ADD CONSTRAINT "OrgUnitenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PAQ PAQ_PAQ_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PAQ"
    ADD CONSTRAINT "PAQ_PAQ_ProcessusId_fkey" FOREIGN KEY ("PAQ_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PAQ PAQ_PAQ_QualityManagerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PAQ"
    ADD CONSTRAINT "PAQ_PAQ_QualityManagerId_fkey" FOREIGN KEY ("PAQ_QualityManagerId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Preuve Preuve_PV_ActionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Preuve"
    ADD CONSTRAINT "Preuve_PV_ActionId_fkey" FOREIGN KEY ("PV_ActionId") REFERENCES public."Action"("ACT_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Preuve Preuve_PV_AuditId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Preuve"
    ADD CONSTRAINT "Preuve_PV_AuditId_fkey" FOREIGN KEY ("PV_AuditId") REFERENCES public."Audit"("AU_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Preuve Preuve_PV_DocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Preuve"
    ADD CONSTRAINT "Preuve_PV_DocumentId_fkey" FOREIGN KEY ("PV_DocumentId") REFERENCES public."Document"("DOC_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Preuve Preuve_PV_NCId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Preuve"
    ADD CONSTRAINT "Preuve_PV_NCId_fkey" FOREIGN KEY ("PV_NCId") REFERENCES public."NonConformite"("NC_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Preuve PreuvtenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Preuve"
    ADD CONSTRAINT "PreuvtenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProcessReview ProcessReview_PRV_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProcessReview"
    ADD CONSTRAINT "ProcessReview_PRV_ProcessusId_fkey" FOREIGN KEY ("PRV_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProcessReview ProcessReview_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProcessReview"
    ADD CONSTRAINT "ProcessReview_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProcessType ProcessTytenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProcessType"
    ADD CONSTRAINT "ProcessTytenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Processus Processus_PR_CoPiloteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Processus"
    ADD CONSTRAINT "Processus_PR_CoPiloteId_fkey" FOREIGN KEY ("PR_CoPiloteId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Processus Processus_PR_PiloteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Processus"
    ADD CONSTRAINT "Processus_PR_PiloteId_fkey" FOREIGN KEY ("PR_PiloteId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Processus Processus_PR_TypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Processus"
    ADD CONSTRAINT "Processus_PR_TypeId_fkey" FOREIGN KEY ("PR_TypeId") REFERENCES public."ProcessType"("PT_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Processus ProcessutenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Processus"
    ADD CONSTRAINT "ProcessutenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Reclamation Reclamation_REC_OwnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reclamation"
    ADD CONSTRAINT "Reclamation_REC_OwnerId_fkey" FOREIGN KEY ("REC_OwnerId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reclamation Reclamation_REC_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reclamation"
    ADD CONSTRAINT "Reclamation_REC_ProcessusId_fkey" FOREIGN KEY ("REC_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Reclamation Reclamation_REC_TierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reclamation"
    ADD CONSTRAINT "Reclamation_REC_TierId_fkey" FOREIGN KEY ("REC_TierId") REFERENCES public."Tier"("TR_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reclamation Reclamation_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reclamation"
    ADD CONSTRAINT "Reclamation_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RevueDirection RevueDirection_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RevueDirection"
    ADD CONSTRAINT "RevueDirection_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RiskType RiskTytenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskType"
    ADD CONSTRAINT "RiskTytenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Risk Risk_RS_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Risk"
    ADD CONSTRAINT "Risk_RS_ProcessusId_fkey" FOREIGN KEY ("RS_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Risk Risk_RS_TypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Risk"
    ADD CONSTRAINT "Risk_RS_TypeId_fkey" FOREIGN KEY ("RS_TypeId") REFERENCES public."RiskType"("RT_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Risk Risk_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Risk"
    ADD CONSTRAINT "Risk_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SSEEvent SSEEvent_SSE_ProcessusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEEvent"
    ADD CONSTRAINT "SSEEvent_SSE_ProcessusId_fkey" FOREIGN KEY ("SSE_ProcessusId") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SSEEvent SSEEvent_SSE_ReporterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEEvent"
    ADD CONSTRAINT "SSEEvent_SSE_ReporterId_fkey" FOREIGN KEY ("SSE_ReporterId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SSEEvent SSEEvent_SSE_SiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEEvent"
    ADD CONSTRAINT "SSEEvent_SSE_SiteId_fkey" FOREIGN KEY ("SSE_SiteId") REFERENCES public."Site"("S_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SSEEvent SSEEvent_SSE_VictimId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEEvent"
    ADD CONSTRAINT "SSEEvent_SSE_VictimId_fkey" FOREIGN KEY ("SSE_VictimId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SSEEvent SSEEventenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEEvent"
    ADD CONSTRAINT "SSEEventenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SSEStats SSESttenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SSEStats"
    ADD CONSTRAINT "SSESttenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SecurityAuditLog SecurityAuditLog_SAL_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SecurityAuditLog"
    ADD CONSTRAINT "SecurityAuditLog_SAL_UserId_fkey" FOREIGN KEY ("SAL_UserId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SecurityAuditLog SecurityAuditLog_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SecurityAuditLog"
    ADD CONSTRAINT "SecurityAuditLog_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Signature Signature_SIG_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Signature"
    ADD CONSTRAINT "Signature_SIG_UserId_fkey" FOREIGN KEY ("SIG_UserId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Signature SignatutenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Signature"
    ADD CONSTRAINT "SignatutenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site SitenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "SitenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Ticket TicketenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "TicketenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Tier TietenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tier"
    ADD CONSTRAINT "TietenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Transaction Transaction_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserCompetence UserCompetence_UC_CompetenceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserCompetence"
    ADD CONSTRAINT "UserCompetence_UC_CompetenceId_fkey" FOREIGN KEY ("UC_CompetenceId") REFERENCES public."Competence"("CP_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserCompetence UserCompetence_UC_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserCompetence"
    ADD CONSTRAINT "UserCompetence_UC_UserId_fkey" FOREIGN KEY ("UC_UserId") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_U_OrgUnitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_U_OrgUnitId_fkey" FOREIGN KEY ("U_OrgUnitId") REFERENCES public."OrgUnit"("OU_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: User User_U_SiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_U_SiteId_fkey" FOREIGN KEY ("U_SiteId") REFERENCES public."Site"("S_Id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: User UsetenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "UsetenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ParticipantsCauserie _ParticipantsCauserie_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_ParticipantsCauserie"
    ADD CONSTRAINT "_ParticipantsCauserie_A_fkey" FOREIGN KEY ("A") REFERENCES public."Causerie"("CS_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ParticipantsCauserie _ParticipantsCauserie_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_ParticipantsCauserie"
    ADD CONSTRAINT "_ParticipantsCauserie_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"("U_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ProcessGovernance _ProcessGovernance_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_ProcessGovernance"
    ADD CONSTRAINT "_ProcessGovernance_A_fkey" FOREIGN KEY ("A") REFERENCES public."GovernanceActivity"("GA_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ProcessGovernance _ProcessGovernance_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_ProcessGovernance"
    ADD CONSTRAINT "_ProcessGovernance_B_fkey" FOREIGN KEY ("B") REFERENCES public."Processus"("PR_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PAQ tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PAQ"
    ADD CONSTRAINT "tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"("T_Id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict TlTdCGasVZdB1FggkE9yGXWKvkAwyk1wenALcNbaIeSr7GvVnlDrByETrHTv7NC

